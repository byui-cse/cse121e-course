game_show
=====

An OTP library

Build
-----

    $ rebar3 compile

Run Unit Tests
-----

    $ rebar3 eunit