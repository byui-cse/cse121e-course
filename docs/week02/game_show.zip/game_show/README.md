game_show
=====

An OTP application

Build
-----

    $ rebar3 compile
