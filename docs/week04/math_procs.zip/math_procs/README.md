math_procs
=====

An OTP library

Build
-----

    $ rebar3 compile
