shop
=====

An OTP library

Build
-----

    $ rebar3 compile
