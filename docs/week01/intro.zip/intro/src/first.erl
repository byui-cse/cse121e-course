-module(first).
-export([printout/0]).


printout()->
	io:format("It worked!!~n").

